# Admin Panel Setup Instructions

## Overview
This admin panel has been successfully integrated into your ASP.NET Core MVC project. It provides a complete administrative interface with authentication, user management, job listings, mentors, assessments, messages, and system settings.

## Features
- **Secure Authentication**: Admin login with username "admin" and password "admin123"
- **Responsive Design**: Modern, mobile-friendly UI using Bootstrap 5
- **Dashboard**: Overview of platform statistics and recent activity
- **User Management**: View and manage all registered users
- **Job Listings**: Manage job postings and applications
- **Mentors**: Manage mentors and mentorship sessions
- **Assessments**: Monitor career assessments and results
- **Messages**: Handle contact messages and communications
- **Settings**: Configure system settings and preferences

## Setup Instructions

### 1. Database Setup
1. Open SQL Server Management Studio (SSMS)
2. Connect to your SQL Server instance
3. Execute the `AdminPanelDatabase.sql` file to create the admin database and tables
4. The script will create:
   - `AdminUsers` table with the default admin user
   - Default admin credentials: Username: `admin`, Password: `admin123`

### 2. Connection String Configuration
Update the connection string in `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SERVER;Database=AdminPanelDB;Trusted_Connection=true;TrustServerCertificate=true;"
  }
}
```
Replace `YOUR_SERVER` with your SQL Server instance name.

### 3. Project Dependencies
The following NuGet package has been added to your project:
- `Microsoft.Data.SqlClient` (Version 5.1.2)

If you need to restore packages, run:
```bash
dotnet restore
```

### 4. Build and Run
1. Build the project:
   ```bash
   dotnet build
   ```
2. Run the project:
   ```bash
   dotnet run
   ```

### 5. Access Admin Panel
1. Navigate to: `https://localhost:5001/Admin/Login` (or your configured port)
2. Login with:
   - **Username**: admin
   - **Password**: admin123
3. You'll be redirected to the admin dashboard

## File Structure

### New Files Added:
```
WebApplication7/
├── Controllers/
│   └── AdminController.cs                 # Admin authentication and panel controller
├── Models/
│   ├── AdminUser.cs                      # Admin user model
│   └── AdminLoginViewModel.cs            # Login view model
├── Services/
│   ├── IAdminService.cs                  # Admin service interface
│   └── AdminService.cs                   # Admin service implementation
└── Views/
    ├── Admin/
    │   ├── Login.cshtml                  # Admin login page
    │   ├── Dashboard.cshtml              # Admin dashboard
    │   ├── Users.cshtml                  # User management
    │   ├── Jobs.cshtml                   # Job listings management
    │   ├── Mentors.cshtml                # Mentors management
    │   ├── Assessments.cshtml            # Assessments management
    │   ├── Messages.cshtml               # Messages management
    │   └── Settings.cshtml               # System settings
    └── Shared/
        └── _AdminLayout.cshtml           # Admin panel layout
```

### Modified Files:
- `Program.cs` - Added admin service registration
- `WebApplication7.csproj` - Added NuGet package reference
- `appsettings.json` - Added connection string configuration

## Security Features
- **Session-based Authentication**: Secure admin sessions
- **Password Hashing**: Admin passwords are hashed using SHA256
- **Authorization**: Admin-only access to panel routes
- **Session Timeout**: Automatic logout after inactivity

## Customization

### Changing Admin Credentials
To change the admin username or password:
1. Update the record in the `AdminUsers` table
2. For password changes, hash the new password using SHA256
3. Or modify the `AdminService.cs` to use a different hashing method

### Adding New Admin Users
Execute SQL to add new admin users:
```sql
INSERT INTO AdminUsers (Username, PasswordHash, Email, FullName, Role)
VALUES ('newadmin', 'HASHED_PASSWORD', 'newadmin@email.com', 'New Admin', 'Admin');
```

### Styling Customization
- Modify `Views/Shared/_AdminLayout.cshtml` for layout changes
- Update CSS variables in the `<style>` section for color scheme changes
- Add custom CSS files in `wwwroot/css/` for additional styling

## Troubleshooting

### Common Issues:
1. **Database Connection Error**: Verify connection string and SQL Server access
2. **Login Issues**: Ensure database is created and admin user exists
3. **Permission Errors**: Check SQL Server permissions for the application user
4. **Port Conflicts**: Update port numbers in launch settings if needed

### Logs and Debugging:
- Check console output for detailed error messages
- Enable detailed logging in `appsettings.json` if needed
- Use browser developer tools to debug frontend issues

## Support
The admin panel is fully integrated and ready to use. All views are responsive and work on desktop, tablet, and mobile devices. The interface follows modern design principles with intuitive navigation and clear visual hierarchy.

For any customizations or additional features, you can extend the existing controllers and views following the established patterns in the codebase.

