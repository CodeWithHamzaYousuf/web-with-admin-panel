using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;
using WebApplication7.Services;

namespace WebApplication7.Controllers
{
    public class AdminController : Controller
    {
        private readonly IAdminService _adminService;

        public AdminController(IAdminService adminService)
        {
            _adminService = adminService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            // If already logged in, redirect to dashboard
            if (IsAdminLoggedIn())
            {
                return RedirectToAction("Dashboard");
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(AdminLoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var admin = await _adminService.AuthenticateAsync(model.Username, model.Password);
            if (admin != null)
            {
                // Set session
                HttpContext.Session.SetInt32("AdminId", admin.Id);
                HttpContext.Session.SetString("AdminUsername", admin.Username);
                HttpContext.Session.SetString("AdminRole", admin.Role);

                return RedirectToAction("Dashboard");
            }

            ModelState.AddModelError("", "Invalid username or password.");
            return View(model);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        public IActionResult Dashboard()
        {
            if (!IsAdminLoggedIn())
            {
                return RedirectToAction("Login");
            }

            ViewBag.AdminUsername = HttpContext.Session.GetString("AdminUsername");
            return View();
        }

        public IActionResult Users()
        {
            if (!IsAdminLoggedIn())
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        public IActionResult Jobs()
        {
            if (!IsAdminLoggedIn())
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        public IActionResult Mentors()
        {
            if (!IsAdminLoggedIn())
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        public IActionResult Assessments()
        {
            if (!IsAdminLoggedIn())
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        public IActionResult Messages()
        {
            if (!IsAdminLoggedIn())
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        public IActionResult Settings()
        {
            if (!IsAdminLoggedIn())
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        private bool IsAdminLoggedIn()
        {
            return HttpContext.Session.GetInt32("AdminId").HasValue;
        }
    }
}

