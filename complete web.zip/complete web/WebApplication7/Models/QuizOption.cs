﻿namespace WebApplication7.Models
{
    public class QuizOption
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string AssociatedTrait { get; set; }
    }
}
