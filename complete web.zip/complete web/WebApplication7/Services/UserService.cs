using WebApplication7.Models;

namespace WebApplication7.Services
{
    public class UserService
    {
        private static List<User> _users = new List<User>();
        private static int _nextId = 1;

        public bool RegisterUser(SignupViewModel model)
        {
            // Check if username or email already exists
            if (_users.Any(u => u.Username == model.Username || u.Email == model.Email))
            {
                return false;
            }

            var user = new User
            {
                Id = _nextId++,
                Username = model.Username,
                Email = model.Email,
                Password = model.Password, // In production, hash the password
                CreatedAt = DateTime.Now
            };

            _users.Add(user);
            return true;
        }

        public User? ValidateUser(LoginViewModel model)
        {
            return _users.FirstOrDefault(u => u.Username == model.Username && u.Password == model.Password);
        }

        public bool UserExists(string username, string email)
        {
            return _users.Any(u => u.Username == username || u.Email == email);
        }
    }
}

